# ДЗ 8

A Pen created on CodePen.io. Original URL: [https://codepen.io/mhpguwpu-the-builder/pen/KKYrXNd](https://codepen.io/mhpguwpu-the-builder/pen/KKYrXNd).

